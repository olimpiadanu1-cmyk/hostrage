/**
 * Rage Russia | Evidence Hub - Configurable Forum Helper (Fresh ID Edition)
 */
var RageEvidenceHub = (function() {
    'use strict';

    let config = {
        targets: 'Доказательства\nquestions[5]',
        url: 'http://localhost:4000'
    };

    function init() {
        if (window.RageEvidenceHubConfig) {
            // Updated to use the new field names from our fresh options.xml
            config.targets = JSON.parse(window.RageEvidenceHubConfig.targets || '"Доказательства"');
            config.url = JSON.parse(window.RageEvidenceHubConfig.url || '"http://localhost:4000"');
        }

        console.log('Rage Evidence Hub: Initializing (v1.1)...');
        
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length > 0) {
                    injectButtons();
                }
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });
        injectButtons();

        window.addEventListener('message', function(event) {
            try {
                const hubOrigin = new URL(config.url).origin;
                if (event.origin !== hubOrigin) return;

                if (event.data && event.data.type === 'RAGE_EVIDENCE_SUCCESS') {
                    handleUploadSuccess(event.data.url);
                }
            } catch (e) {}
        });
    }

    let activeInput = null;

    function injectButtons() {
        if (!config.targets) return;
        const targets = config.targets.split(/\n|,/).map(t => t.trim()).filter(t => t);

        targets.forEach(target => {
            const nameInputs = document.querySelectorAll(`[name="${target}"], [name="custom_fields[${target}]"]`);
            nameInputs.forEach(input => {
                if (shouldInject(input)) createButton(input);
            });

            const idInput = document.getElementById(target);
            if (idInput && shouldInject(idInput)) createButton(idInput);

            const rows = document.querySelectorAll('.formRow');
            rows.forEach(row => {
                const label = row.querySelector('dt');
                if (label && label.textContent.includes(target) && !row.dataset.hubInjected) {
                    const input = row.querySelector('input, textarea');
                    if (input && shouldInject(input)) {
                        createButton(input);
                        row.dataset.hubInjected = 'true';
                    }
                }
            });
        });
    }

    function shouldInject(element) {
        return element && !element.dataset.hubInjected && (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA');
    }

    function createButton(input) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'button button--icon button--icon--upload rage-evidence-btn';
        btn.style.marginLeft = '10px';
        btn.style.verticalAlign = 'top';
        btn.innerHTML = '<span class="button-text">Загрузить улики</span>';
        
        btn.onclick = function(e) {
            e.preventDefault();
            activeInput = input;
            const w = 600, h = 800;
            const left = (screen.width/2)-(w/2);
            const top = (screen.height/2)-(h/2);
            window.open(config.url, 'RageEvidenceHub', 'width='+w+',height='+h+',top='+top+',left='+left);
        };

        input.parentNode.insertBefore(btn, input.nextSibling);
        input.dataset.hubInjected = 'true';
    }

    function handleUploadSuccess(url) {
        if (activeInput) {
            const currentVal = activeInput.value.trim();
            activeInput.value = currentVal ? `${currentVal}\n${url}` : url;
            activeInput.dispatchEvent(new Event('change', { bubbles: true }));
            activeInput.style.transition = 'background-color 0.5s';
            activeInput.style.backgroundColor = 'rgba(255, 0, 0, 0.1)';
            setTimeout(() => activeInput.style.backgroundColor = '', 1000);
        }
    }

    return { init: init };
})();

if (window.XF) {
    XF.Element.extend('custom-fields', {
        __backup: { 'init': 'init' },
        init: function() {
            this.__backup.init();
            RageEvidenceHub.init();
        }
    });
} else {
    document.addEventListener('DOMContentLoaded', RageEvidenceHub.init);
}
